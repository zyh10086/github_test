/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50022
 Source Host           : localhost:3306
 Source Schema         : wz

 Target Server Type    : MySQL
 Target Server Version : 50022
 File Encoding         : 65001

 Date: 17/05/2020 00:36:47
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `logname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '管理员登录名',
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '管理员密码',
  PRIMARY KEY USING BTREE (`logname`)
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'InnoDB free: 11264 kB' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('Lucy', '666666');
INSERT INTO `admin` VALUES ('Timi', '666666');

-- ----------------------------
-- Table structure for engineer
-- ----------------------------
DROP TABLE IF EXISTS `engineer`;
CREATE TABLE `engineer`  (
  `ID` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '编号为数字，编号使用4为位数字，格式为0001、0002….，不能重复。',
  `EngineerName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '姓名：为字符，最长不超过20个字符。不能为空。',
  `Sex` int(2) NOT NULL DEFAULT '' COMMENT '用数字表示0表示女，1表示男。不能为其它数值',
  `Birthday` date NOT NULL DEFAULT '' COMMENT '生日：用数字分别表示年、月、日。格式例如：年使用四位数字表示，月使用1-12表示,日使用1-31表示。范围是（1900，2004）',
  `Education` int(2) NOT NULL DEFAULT '',
  `NativePlace` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '籍贯：使用字符表示，最长不超过10个字符。不能为空。',
  `Address` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '地址：使用字符表示，最长不超过30个字符。不能为空。',
  `PhoneNumber` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '电话：0<表示长度<=15，有分机时在后面使用’-’接分机号',
  `Seniority` int(50) NOT NULL DEFAULT '' COMMENT '0<工龄<50',
  `BasicWage` double(10, 2) NOT NULL DEFAULT '' COMMENT '0<工资',
  PRIMARY KEY USING BTREE (`ID`)
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'InnoDB free: 11264 kB' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of engineer
-- ----------------------------
INSERT INTO `engineer` VALUES ('0002', '小鲁班', 1, '1999-09-24', 3, '浙江杭州', '浙江农林大学', '18999887788', 23, 2444.00);
INSERT INTO `engineer` VALUES ('0004', '小春', 1, '1999-09-24', 3, '浙江', '浙江', '124356', 23, 2435.00);
INSERT INTO `engineer` VALUES ('0005', '何泳', 0, '1999-08-23', 3, '天堂', '瑶池', '199997778', 23, 23333.00);

-- ----------------------------
-- Table structure for salary
-- ----------------------------
DROP TABLE IF EXISTS `salary`;
CREATE TABLE `salary`  (
  `Mbenefit` double(10, 2) NOT NULL DEFAULT '',
  `ID` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `Minsurance` double(10, 2) NOT NULL DEFAULT '',
  `Msalary` double(10, 2) NOT NULL DEFAULT '',
  `day` int(255) DEFAULT NULL,
  PRIMARY KEY USING BTREE (`ID`)
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'InnoDB free: 11264 kB' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of salary
-- ----------------------------
INSERT INTO `salary` VALUES (1.00, '0002', 1.00, 1.00, NULL);
INSERT INTO `salary` VALUES (1.00, '1', 1.00, 1.00, NULL);
INSERT INTO `salary` VALUES (1.00, '2', 2.00, 8305.11, 23);
INSERT INTO `salary` VALUES (1.00, '2.0', 1.00, 8306.11, NULL);
INSERT INTO `salary` VALUES (4000.00, '4', 200.00, 2999.50, 20);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `logname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '用户名，≤20字符，非空',
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '密码，≤20字符，非空',
  PRIMARY KEY USING BTREE (`logname`)
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'InnoDB free: 11264 kB' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('winner', '666666');
INSERT INTO `user` VALUES ('何泳', '888888');
INSERT INTO `user` VALUES ('春春', '123');

SET FOREIGN_KEY_CHECKS = 1;
